# BlockSentinel Pro

**Cinematic, evidence-first Solidity security workbench.**

BlockSentinel Pro combines a 3D-inspired animated interface with a local analysis API, optional Slither integration, Solidity AST parsing through `solc` standard JSON output, SARIF 2.1.0 export, GitHub pull-request scanning, baseline comparison, and Foundry-oriented test fixtures.

> **Security disclaimer:** this project is a developer triage tool, not a formal audit or proof of safety. Static analysis can produce false positives and false negatives. Do not use a clean report as the sole basis for deploying contracts or handling funds.

## Features

- Cinematic animated blockchain hero (Canvas motion graphics; no remote assets required)
- FastAPI analysis API and downloadable Markdown, JSON, and SARIF reports
- Optional Slither adapter (uses the installed `slither` CLI when available)
- Solidity AST parsing via `solc --standard-json` (when `solc` is installed)
- Heuristic fallback detectors for `tx.origin`, low-level calls, and floating pragmas
- Finding baseline comparison (`introduced`, `resolved`, `unchanged`)
- GitHub Action for pull requests, SARIF upload, and optional baseline diff
- Foundry sample contracts and tests
- Docker, CI, threat model, architecture docs, and contribution guidance

## Quick start

Python 3.11+ recommended.

```bash
python -m venv .venv
source .venv/bin/activate # Windows: .venv\Scripts\activate
pip install -r requirements-dev.txt
uvicorn app.main:app --reload
```

Open `http://127.0.0.1:8000`.

## Optional deep-analysis tools

### Slither

Install Slither and its prerequisites following the official docs: https://github.com/crytic/slither#how-to-install

Then verify:

```bash
slither --version
```

When the `slither` executable is available, the API can write source into a temporary directory and invoke Slither with JSON output. Do not expose this endpoint to untrusted users without process isolation, strict resource limits, and a sandbox.

### Solidity compiler / AST

Install a supported `solc` binary and verify `solc --version`. BlockSentinel requests the compiler's AST via Standard JSON. If no compiler is found, AST parsing is reported as unavailable rather than silently fabricated.

### Foundry

Install Foundry using its official instructions: https://book.getfoundry.sh/getting-started/installation

From `contracts/`:

```bash
forge test -vv
```

The fixtures are educational and should not be considered audited production contracts.

## API

- `GET /api/health`
- `POST /api/analyze` — heuristic checks plus optional Slither and AST
- `POST /api/report/sarif` — SARIF 2.1.0
- `POST /api/report/markdown` — Markdown report
- `POST /api/compare` — compare two finding lists
- `GET /api/capabilities` — available local analysis tools

Example:

```bash
curl -s http://127.0.0.1:8000/api/analyze \
  -H 'Content-Type: application/json' \
  -d '{"source":"// SPDX-License-Identifier: MIT\npragma solidity ^0.8.20; contract Demo { function f() external view returns(address) { return tx.origin; }}","filename":"Demo.sol","use_slither":false,"use_ast":false}'
```

## GitHub Action

Copy `.github/workflows/blocksentinel.yml` into your repository or use it as a reference. It installs Python dependencies and Slither, scans Solidity files, writes SARIF, and uploads it to GitHub code scanning. In repository settings, enable GitHub Code Security / code scanning as available for your plan and repository visibility.

## Deployment and online demo

This repository is deployable as a container, but **no public demo has been provisioned by this generator**. Deploy to a service you control (for example, a container host) only after adding authentication, rate limiting, a privacy notice, and sandboxing. Never send confidential source to an untrusted public instance.

## Security limitations

- Regex checks are heuristics, not compiler proofs.
- AST parsing provides structural context but does not itself prove a vulnerability.
- Slither execution runs an external process; isolate it before public multi-tenant hosting.
- Current baseline comparison is deterministic but should be combined with repository-specific triage.
- The animated hero is a visual treatment, not a live blockchain connection.

## Documentation

- `docs/ARCHITECTURE.md`
- `docs/THREAT_MODEL.md`
- `docs/DEVELOPMENT.md`
- `docs/DEMO_DEPLOYMENT.md`
- `docs/ANALYSIS_PIPELINE.md`

## License

MIT. See `LICENSE`.
